// DSAStackTestHarness.java
import java.io.*;
import io.*;
import java.util.*;

// Test harness for the DSAStack class.
//

public class DSAStackTestHarness
{	
   public static void main(String args[])
   {
      int iNumPassed = 0;
      int iNumTests = 0;
      DSAStack<String> stack;
      
      // Test with normal conditions (shouldn't throw exceptions)
      System.out.println("\n");
      System.out.println("Testing Normal Conditions - Constructor");
      System.out.println("=======================================");
      try
      {   
         iNumTests++;
         System.out.println(iNumTests + ": Testing creation of DSAStack: ");
         stack = new DSAStack<String>();
         iNumPassed++;
         System.out.println("passed");
         
         iNumTests++;
         System.out.print(iNumTests + ": Testing isEmpty: ");
	     System.out.println("Expected is true: " + stack.isEmpty() );
         iNumPassed++;
         System.out.println("passed");
         
         try
         {
            iNumTests++;
            System.out.print(iNumTests + ": Testing push: ");
	        System.out.println("Expected should pass since stack empty: ");
            stack.push("1");
            stack.push("2");
            stack.push("3");
            stack.push("4");
            iNumPassed++;
            System.out.println("passed, items sucessfully pushed");
         }
         catch(IllegalArgumentException e)
         {
             System.out.println("fail: " + e.getMessage());
         }

         iNumTests++;
         System.out.print(iNumTests + ": Testing isEmpty: ");
	     System.out.println("Expected is false: " + stack.isEmpty() );
         iNumPassed++;
         System.out.println("passed");

         try
         {
            iNumTests++;
            System.out.print(iNumTests + ": Testing push: ");
	        System.out.println("Expected should pass since 1 more space availiable: ");
            stack.push("5");
            iNumPassed++;
            System.out.println("passed, item sucessfully pushed");
         }
         catch(IllegalArgumentException e)
         {
             System.out.println("fail: " + e.getMessage());
         }


         try
         {
            iNumTests++;
            System.out.print(iNumTests + ": Testing pop: ");
	        System.out.println("Expected pass since stack is not empty: ");
            System.out.println("passed, item " + stack.pop() +  " sucessfully popped");
            iNumPassed++;
         }
         catch(IllegalArgumentException e)
         {
             System.out.println("fail: " + e.getMessage());
         }

         try
         {
            iNumTests++;
            System.out.print(iNumTests + ": Testing top: ");
	        System.out.println("Expected pass since stack is not empty: ");
            System.out.println("passed, item " + stack.top() +  " is on top of stack");
            iNumPassed++;
         }
         catch(IllegalArgumentException e)
         {
             System.out.println("fail: " + e.getMessage());
         }

      }
      catch(IllegalArgumentException e)
      {
         System.out.println("Illegal Argument:" + e.getMessage());
      }
      catch(Exception e)
      {
         System.out.println("FAILED");
      }

      System.out.println("Test Normal conditions result:" + iNumPassed + " passes for tests");

   // Tests with error conditions (SHOULD throw exceptions)
   // no point testing getCount, isEmpty and isFull since there are no exceptions
   // count always starts at 0 when constructed, count is compared to length of array
   // true or false will always be expected
   System.out.println("\n");
   System.out.println("Testing Error Conditions - Constructor");
   System.out.println("======================================");

   try
   {
         iNumTests++;
         System.out.print(iNumTests + ": Testing pop when empty : ");
         stack = new DSAStack<String>();
         stack.pop();
         System.out.println("FAILED");
   }
   catch(Exception e) 
   { 
       iNumPassed++; 
       System.out.println("\npassed, expected error: " + e.getMessage()); 
   }

   try
   {
         iNumTests++;
         System.out.print(iNumTests + ": Testing pop when empty : ");
         stack = new DSAStack<String>();
         stack.top();
         System.out.println("FAILED");
   }
   catch(Exception e) 
   { 
       iNumPassed++; 
       System.out.println("\npassed, expected error: " + e.getMessage()); 
   }
  } // End of main
} // End of Class


