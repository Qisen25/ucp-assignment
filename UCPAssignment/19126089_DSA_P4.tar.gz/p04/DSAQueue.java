/****************************************************************
 * AUTHOR: Kei Sum Wang, student id: 19126089
 * PURPOSE: class implementation of queue ADT
 * Date: 01/04/2018
 * **************************************************************/
import java.util.*; 
public class DSAQueue<E> implements Iterable
{
    //CLASSFIELDS
    private DSALinkedList<E> queue;

    public Iterator<E> iterator()
    {
        return queue.iterator();
    }

    //DEFAULT CONSTRUCTOR
    public DSAQueue()
    {
        queue = new DSALinkedList<E>();
    }

    //ACCESSORS

    public boolean isEmpty()
    {
        return this.queue.isEmpty();
    }

    //MUTATORS
    public void enqueue(E value)
    {
        this.queue.insertLast(value);
    }

    public E dequeue()
    {
        E frontVal;

        if (isEmpty())
        {
            throw new IllegalArgumentException("queue is empty, nothing to dequeue");
        }
        else
        {
            frontVal = peek();
            this.queue.removeFirst();
        }

        return frontVal;

    }

    public E peek()
    {
        E frontVal;

        if (isEmpty())
        {
            throw new IllegalArgumentException("queue is empty, can't find elements");
        }
        else
        {
            frontVal = this.queue.peekFirst();
        }
        return frontVal;
    }

}
