/****************************************************************
 * AUTHOR: Kei Sum Wang, student id: 19126089
 * PURPOSE: class implementation of Stack ADT
 * Date: 01/04/2018
 * **************************************************************/
import java.util.*; 
public class DSAStack<E> implements Iterable
{
    //CLASSFIELDS
    private DSALinkedList<E> stack;

    public Iterator<E> iterator()
    {
        return stack.iterator();
    }

    //DEFAULT CONSTRUCTOR
    public DSAStack()
    {
        this.stack = new DSALinkedList<E>();
    }


    //ACCESSORS
    public boolean isEmpty()
    {
        return this.stack.isEmpty();
    }

    //MUTATOR
    public void push(E value)
    {
        this.stack.insertFirst(value);
    }

    public E pop()
    {
        E topVal;
    
        if (isEmpty())
        {
            throw new IllegalArgumentException("stack empty, nothing to pop");
        }
        else
        {
            topVal = top();
            this.stack.removeFirst();
        }

        return topVal;
    }

    public E top()
    {
        E topVal;

        if (isEmpty())
        {
            throw new IllegalArgumentException("stack array is empty");
        }
        else
        {
            topVal = this.stack.peekFirst();
        }

        return topVal;
    }    
}
