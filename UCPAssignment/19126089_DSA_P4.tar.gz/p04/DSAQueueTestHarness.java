// DSAQueueTestHarness.java
import java.io.*;
import io.*;

// Test harness for the DSAQueue class.
//

public class DSAQueueTestHarness
{	
   public static void main(String args[])
   {
      int iNumPassed = 0;
      int iNumTests = 0;
      DSAQueue<String> q;
      
      // Test with normal conditions (shouldn't throw exceptions)
      System.out.println("\n");
      System.out.println("Testing Normal Conditions - Constructor");
      System.out.println("=======================================");
      try
      {   
         iNumTests++;
         System.out.println(iNumTests + ": Testing creation of DSAQueue: ");
         q = new DSAQueue<String>();
         iNumPassed++;
         System.out.println("passed");
         
         iNumTests++;
         System.out.print(iNumTests + ": Testing isEmpty: ");
	     System.out.println("Expected is true: " + q.isEmpty() );
         iNumPassed++;
         System.out.println("passed");

         try
         {
            iNumTests++;
            System.out.print(iNumTests + ": Testing enqueue: ");
	        System.out.println("Expected should pass since queue empty: ");
            q.enqueue("1");
            q.enqueue("2");
            q.enqueue("3");
            q.enqueue("4");
            iNumPassed++;
            System.out.println("passed, items sucessfully enqueued");
         }
         catch(IllegalArgumentException e)
         {
             System.out.println("fail: " + e.getMessage());
         }

         iNumTests++;
         System.out.print(iNumTests + ": Testing isEmpty: ");
	     System.out.println("Expected is false: " + q.isEmpty() );
         iNumPassed++;
         System.out.println("passed");

         try
         {
            iNumTests++;
            System.out.print(iNumTests + ": Testing enqueue: ");
	        System.out.println("Expected should pass since more space availiable: ");
            q.enqueue("5");
            iNumPassed++;
            System.out.println("passed, item sucessfully enqueued");
         }
         catch(IllegalArgumentException e)
         {
             System.out.println("fail: " + e.getMessage());
         }

         iNumTests++;
         System.out.print(iNumTests + ": Testing isEmpty: ");
	     System.out.println("Expected is false after enqueue test: " + q.isEmpty() );
         iNumPassed++;
         System.out.println("passed");

         try
         {
            iNumTests++;
            System.out.print(iNumTests + ": Testing dequeue: ");
	        System.out.println("Expected pass since queue is not empty: ");
            System.out.println("passed, item " + q.dequeue() +  " sucessfully dequeued");
            iNumPassed++;
         }
         catch(IllegalArgumentException e)
         {
             System.out.println("fail: " + e.getMessage());
         }

         try
         {
            iNumTests++;
            System.out.print(iNumTests + ": Testing peek: ");
	        System.out.println("Expected pass since stack is not empty: ");
            System.out.println("passed, item " + q.peek() +  " is on top of stack");
            iNumPassed++;
         }
         catch(IllegalArgumentException e)
         {
             System.out.println("fail: " + e.getMessage());
         }

      }
      catch(IllegalArgumentException e)
      {
         System.out.println("Illegal Argument:" + e.getMessage());
      }
      catch(Exception e)
      {
         System.out.println("FAILED");
      }

      System.out.println("Test Normal conditions result:" + iNumPassed + " passes for tests");

   // Tests with error conditions (SHOULD throw exceptions)
   // no point testing getCount, isEmpty and isFull since there are no exceptions
   // count always starts at 0 when constructed, count is compared to length of array
   // true or false will always be expected
   System.out.println("\n");
   System.out.println("Testing Error Conditions - Constructor");
   System.out.println("======================================");
   try
   {
         iNumTests++;
         System.out.print(iNumTests + ": Testing dequeue when empty : ");
         q = new DSAQueue<String>();
         q.dequeue();
         System.out.println("FAILED");
   }
   catch(Exception e) 
   { 
       iNumPassed++; 
       System.out.println("\npassed, expected error: " + e.getMessage()); 
   }

   try
   {
         iNumTests++;
         System.out.print(iNumTests + ": Testing peek when empty : ");
         q = new DSAQueue<String>();
         q.peek();
         System.out.println("FAILED");
   }
   catch(Exception e) 
   { 
       iNumPassed++; 
       System.out.println("\npassed, expected error: " + e.getMessage()); 
   }

  } // End of main
} // End of Class


