 /***************************************************************************
 *  FILE: TestLinkedList.java
 *  AUTHOR: Connor Beardsmore - 15504319
 *  UNIT: DSA120 Prac 8
 *  PURPOSE: Basic Test Harness For Linked List
 *  LAST MOD: 12/10/15
 *  REQUIRES: NONE
 ***************************************************************************/

import java.io.*;
import java.util.*;

public class UnitTestLinkedList
{
	public static void main(String args[])
	{
        // VARIABLE DECLARATIONS
        int iNumPassed = 0;
        int iNumTests = 0;
        DSALinkedList<String> ll = null;
        String sTestString;
        Object nodeValue;

//---------------------------------------------------------------------------

        System.out.println("\n\nTesting Normal Conditions - Constructor");
        System.out.println("=======================================");

        // TEST 1 : CONSTRUCTOR
        try {
            iNumTests++;
            ll = new DSALinkedList<String>();
            System.out.print("Testing creation of DSALinkedList (isEmpty()): ");
            if (ll.isEmpty() == false)
                throw new IllegalArgumentException("Head must be null.");
            iNumPassed++;
            System.out.println("passed");
        } catch(Exception e) { System.out.println("FAILED"); }

//---------------------------------------------------------------------------

        System.out.println("\nTest inserting first and removing first (stack behaviour)");
        System.out.println("==========================================================");

        // TEST 2 : INSERT FIRST
        try {
            iNumTests++;
            System.out.print("Testing insertFirst(): ");
            ll.insertFirst("abc");
            ll.insertFirst("jkl");
            ll.insertFirst("xyz");
            iNumPassed++;
            System.out.println("passed");
        } catch(Exception e) { System.out.println("FAILED"); }

        // TEST 3 : TEST ITERATOR
        try
        {
            iNumTests++;
            System.out.println("Testing iterator with insert first");
            Iterator<String> it = ll.iterator();
            while(it.hasNext())
            {
                String test = it.next();
                if (test == "abc")
                {
                    System.out.println(test + " = " + "abc (EXPECTED)");
                }
                else if (test == "jkl")
                {
                    System.out.println(test + " = " + "jkl (EXPECTED)");
                }
                else if (test == "xyz")
                {
                    System.out.println(test + " = " + "xyz (EXPECTED)");
                }
                else
                {
                    throw new IllegalArgumentException("FAILED");
                }
            }
            iNumPassed++;
            System.out.println("passed");
        } catch(Exception e) { System.out.println("FAILED.4" + e.getMessage()); }

        // TEST 4 : PEEK LAST
        try {
            iNumTests++;
            System.out.print("Testing peekLast(): ");
            if (ll.peekLast() != "abc")
                throw new IllegalArgumentException("FAILED.");
            iNumPassed++;
            System.out.println("passed   ");
        } catch(Exception e) { System.out.println("FAILED"); }

        // TEST 5 : REMOVE FIRST
        try {
            iNumTests++;
            System.out.print("Testing removeFirst(): ");
            if (ll.removeFirst() != "xyz")
                throw new IllegalArgumentException("FAILED.1");
            if (ll.removeFirst() != "jkl")
                throw new IllegalArgumentException("FAILED.2");
            if (ll.removeFirst() != "abc")
                throw new IllegalArgumentException("FAILED.3");
            iNumPassed++;
            System.out.println("passed");
        } catch(Exception e) { System.out.println("FAILED.4"); }

        // TEST 6 : IS EMPTY
        try {
            iNumTests++;
            System.out.print("Testing isEmpty(): ");
            sTestString = (String)ll.removeFirst();
            System.out.println("FAILED");
        } catch(Exception e) { iNumPassed++; System.out.println("passed"); }

//---------------------------------------------------------------------------

        System.out.println("\nTest inserting last and removing first (queue behaviour)");
        System.out.println("========================================================");

        // TEST 7 : INSERT LAST()
        try {
            iNumTests++;
            System.out.print("Testing insertLast(): ");
            ll.insertLast("abc");
            ll.insertLast("jkl");
            ll.insertLast("xyz");
            iNumPassed++;
            System.out.println("passed");
        } catch(Exception e) { System.out.println("FAILED"); }

        // TEST 8 : TEST ITERATOR
        try
        {
            iNumTests++;
            System.out.println("Testing iterator with insert last");
            Iterator<String> it = ll.iterator();
            while(it.hasNext())
            {
                String test = it.next();
                if (test == "abc")
                {
                    System.out.println(test + " = " + "abc (EXPECTED)");
                }
                else if (test == "jkl")
                {
                    System.out.println(test + " = " + "jkl (EXPECTED)");
                }
                else if (test == "xyz")
                {
                    System.out.println(test + " = " + "xyz (EXPECTED)");
                }
                else
                {
                    throw new IllegalArgumentException("FAILED");
                }
            }
            iNumPassed++;
            System.out.println("passed");
        } catch(Exception e) { System.out.println("FAILED.4" + e.getMessage()); }

        // TEST 9 : PEEK LAST
        try {
            iNumTests++;
            System.out.print("Testing peekFirst(): ");
            sTestString = (String)ll.peekFirst();
            if ((String)ll.peekFirst() != "abc")
                throw new IllegalArgumentException("FAILED.");
            iNumPassed++;
            System.out.println("passed");
        } catch(Exception e) { System.out.println("FAILED"); }

        // TEST 10 : REMOVE FIRST
        try {
            iNumTests++;
            System.out.print("Testing removeFirst(): ");
            if (ll.removeFirst() != "abc")
                throw new IllegalArgumentException("FAILED.1");
            if (ll.removeFirst() != "jkl")
                throw new IllegalArgumentException("FAILED.2");
            if (ll.removeFirst() != "xyz")
                throw new IllegalArgumentException("FAILED.3");
            iNumPassed++;
            System.out.println("passed");
        } catch(Exception e) { System.out.println("FAILED.4"); }

        // TEST 11 : IS EMPTY 2
        try {
            iNumTests++;
            System.out.print("Testing isEmpty(): ");
            sTestString = (String)ll.removeFirst();
            System.out.println("FAILED");
        } catch(Exception e) { iNumPassed++; System.out.println("passed"); }




//---------------------------------------------------------------------------

        // PRINT TEST SUMMARY
        System.out.print("\nNumber PASSED: " + iNumPassed + "/" + iNumTests);
        System.out.print(" -> " + (int)(double)iNumPassed/iNumTests*100 + "%\n");
    }
//---------------------------------------------------------------------------
}
