import java.util.*;
public class testLink
{
    public static void main(String [] args)
    {
        DSALinkedList<String> l = new DSALinkedList<String>();
        DSALinkedList<String> p = new DSALinkedList<String>();

        l.insertFirst("abc");
        l.insertFirst("jkl");
        //l.removeLast();
        //l.removeLast();
        //l.insertFirst("xyz");
        //l.removeFirst();
        //String s = (String)l.removeFirst();
        p.insertLast("abc");
        p.insertLast("jkl");
        p.insertLast("xyz");
        //String u = (String)p.removeFirst();
        //p.removeLast();
        //p.removeLast();
        //p.removeFirst();
        //p.removeFirst();
        //p.removeFirst();
        //String j = (String)p.removeFirst();
        //String y = (String)p.removeFirst();

        //System.out.println(s);
        //System.out.println(u);
        
        System.out.println("first insert");
        System.out.println(l.peekFirst());
        System.out.println(l.peekLast());
        System.out.println("last insert");
        System.out.println(p.peekFirst());
        System.out.println(p.peekLast());
        System.out.println("iterator last");
        String myClass;
        Iterator<String> it = l.iterator();
        while(it.hasNext())
        {
            myClass = it.next();
            System.out.println(myClass);
        }



        //System.out.println(j);
        //System.out.println(u);

    }
}
