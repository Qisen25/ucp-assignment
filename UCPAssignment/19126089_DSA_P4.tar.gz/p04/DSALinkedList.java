import java.util.*;
public class DSALinkedList<E> implements Iterable
{
    public Iterator<E> iterator()
    {
        return new DSALinkedListIterator<E>(this);
    }

    //private classes
    private class DSALinkedListIterator<E> implements Iterator<E>
    {
        private DSALinkedList<E>.DSAListNode<E> iterNext;

        public DSALinkedListIterator(DSALinkedList<E> theList)
        {
            iterNext = theList.head;
        }

        public boolean hasNext()
        {
            return (iterNext != null);
        }

        public E next()
        {
            E value;

            if (iterNext == null)
            {
                value = null;
            }
            else
            {
                value = iterNext.getValue();
                iterNext = iterNext.getNext();
            }

            return value;
        }

        public void remove()
        {
            throw new UnsupportedOperationException("Remove not supported");
        }
    }

    private class DSAListNode<E>
    {
        //DSAListNode CLASSFIELDS
        private E value;
        private DSAListNode<E> next;
        private DSAListNode<E> prev;

        public DSAListNode(E inValue)
        {
            value = inValue;

            next = null;
            prev = null;
        }

        //ACCESSORS
        public E getValue()
        {
            return value;
        }

        public DSAListNode<E> getNext()
        {
            return next;
        }

        public DSAListNode<E> getPrevious()
        {
            return prev;
        }

        //MUTATORS
        public void setValue(E inValue)
        {
            value = inValue;
        }

        public void setNext(DSAListNode<E> newNext)
        {
            next = newNext;
        }

        public void setPrevious(DSAListNode<E> newPrev)
        {
            prev = newPrev;
        }
    }

    //DSALinkedList CLASSFIELDS
    private DSAListNode<E> head;
    private DSAListNode<E> tail;

    public DSALinkedList()
    {
        head = null;
        tail = null;
    }

    //MUTATORS
    public void insertFirst(E newValue)
    {
        DSAListNode<E> newNd = new DSAListNode<E>(newValue);
        if (isEmpty())
        {
            this.tail = newNd;
        }
        else
        {
            this.head.setPrevious(newNd);
            newNd.setNext(this.head);
        }

        this.head = newNd;
    }

    public void insertLast(E newValue)
    {
        DSAListNode<E> newNd = new DSAListNode<E>(newValue);
        if (isEmpty())
        {
            this.head = newNd;
        }
        else
        {
            this.tail.setNext(newNd);
            newNd.setPrevious(this.tail);
        }
        this.tail = newNd;
    }

    public E removeFirst()
    {
        E nodeValue;
        DSAListNode<E> currNd;

        nodeValue = this.head.getValue();

        if (isEmpty())
        {
            throw new IllegalArgumentException("list is empty");
        }
        if (this.head.getNext() == null)
        {
            this.tail = null;
        }

        this.head = this.head.getNext();
    
        return nodeValue;
    }

    public E removeLast()
    {
        E nodeValue;
        DSAListNode<E> currNd;

        currNd = this.head;
        if (isEmpty())
        {
            throw new IllegalArgumentException("list is empty");
        }
        else if (this.head.getNext() != null)
        {
            while (currNd.getNext() != null && currNd.getNext() != this.tail)
            {
                currNd = currNd.getNext();
            }// ENDWHILE

            this.tail = currNd;
            this.tail.setNext(null);
        }
        else
        {
            this.head = null;
        }
        nodeValue = currNd.getValue();
        return nodeValue;
    }

    //ACCESORS
    public boolean isEmpty()
    {
        boolean empty;

        empty = (this.head == null);

        return empty;
    }

    public E peekFirst()
    {
        E nodeValue;
        if (isEmpty())
        {
            throw new IllegalArgumentException("list is empty");
        }
        else
        {
            nodeValue = this.head.getValue();
        }

        return nodeValue;
    }

    public E peekLast()
    {
        E nodeValue;
        DSAListNode<E> currNd;
        if (isEmpty())
        {
            throw new IllegalArgumentException("list is empty");
        }
        else
        {
            //currNd = this.tail;
            nodeValue = this.tail.getValue();
        }

        return nodeValue;
   }
            
}
