#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedListNode.h"
#include "journal.h"

#define MAX_CHARS 100

void processFile(char *argv[]);
void printChoice(LinkedList *list, int j);

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        printf("please enter a file and journal entry index\n");
    }
    else
    {
        processFile(argv);
    }

    return 0;
}

/*
 * function read file, passes journal info into struct
 * and calls printChoice function to print journal entry of choice
 * */
void processFile(char *argv[])
{
    FILE *file = fopen(argv[1], "r");
    char str[MAX_CHARS];
    int jIndex, day, month, year, i;
    Journal *journ;
    LinkedList *list = createLinkedList();

    jIndex = atoi(argv[2]);/*convert 2nd arg to an integer*/
    
    if (file == NULL)
    {
        perror("Error reading file\n");
    }

    i = 0;
    fgets(str, MAX_CHARS, file);/*skip first line containing rows*/
    while (fgets(str, MAX_CHARS, file) != NULL)
    {
        journ = (Journal*)malloc(sizeof(Journal));/*every loop allocates 
                                                          a new journal struct*/

        sscanf(str, "%d/%d/%d", &day, &month, &year);/*assign date values
                                                     and store in struct*/        
        journ->day = day;        
        journ->month = month;        
        journ->year = year;

        fgets(str, MAX_CHARS, file);/*read line after and get message*/
        strcpy(journ->text, str);/*must copy string when assigning str
                                   to journ text or error*/
        insertLast(list, journ);/*insert last for ascending order*/
        
       
    }

    fclose(file);
    /*printJournal(list);*/
    printChoice(list, jIndex);
    freeLinkedList(list);
}

/*
 * function print journal data selected by user specified integer
 * */
void printChoice(LinkedList *list, int j)
{
    int listLength = getLength(list);
    Journal *entry;
    
    entry = getElement(list, j);/*obtain specified element*/

    if (j < 0)
    {
        printf("index cannot be negative\n");
    }
    else if (j >= listLength)
    {
        printf("Error: index cannot be greater or equal to length of list\n");
    }
    else if (entry == NULL)
    {
        printf("Nothing found at index: %d\n", j);
    }
    else
    {
        printf("%d-%d-%d %s\n", entry->year, entry->month, entry->day, entry->text);   
    }
}

