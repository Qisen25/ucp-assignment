#include <stdio.h>
#include "LinkedListNode.h"

int main(void)
{
    LinkedList *list = createLinkedList();
    int x = 10;
    int b = 21;
    int v = 14;
    int d = 13;
    int c = 12;
    int y = 11;
    int *cho;
    /**
    insertLast(list, &x);
    insertLast(list, &b);
    insertLast(list, &v);
    insertLast(list, &d);
    insertLast(list, &c);
    insertLast(list, &y);
    **/
    insertFirst(list, &x);
    insertFirst(list, &b);
    insertFirst(list, &v);
    insertFirst(list, &d);
    insertFirst(list, &c);
    insertFirst(list, &y);
    
    deleteFirst(list);

    cho = getElement(list, 0);

    if (cho != NULL)
    {
        printf("Element chosen %d\n", *cho);
    }
    else
    {
        printf("index exceeds max list or nothing left\n");
    }
   
    /*print(list); */

    freeLinkedList(list);

    return 0;
}


