#include <stdio.h>
#include <stdlib.h>
#include "LinkedListNode.h"
#include "journal.h"

/*
 * function to create linked list and return in
 * */
LinkedList* createLinkedList()
{
    LinkedList *list = (LinkedList*)malloc(sizeof(LinkedList));
    list->head = NULL;
    list->tail = NULL;

    return list;
}

/*
 * function inserts items first
 * this resembles pushing items on stack
 * */
void insertFirst(LinkedList *list, void *data)
{
    LinkedListNode *newNode = (LinkedListNode*)malloc(sizeof(LinkedListNode));
    /*make sure next and prev are NULL
     * this is important when adding latest item since its next field must 
     * point to NULL otherwise we get an error and may not be be able to use
     * item-> next field
     * */
    newNode->next = NULL;
    newNode->prev = NULL;

    newNode->data = data;/*assign imported data to node data*/
   
    if (list->head == NULL)/*list is empty then assign node to head and tail*/
    {
        list->tail = newNode;
        list->head = newNode;
    }
    else
    {
        list->head->prev = newNode;/*assign new node previous to head*/
        newNode->next = list->head;/*head will be after new node*/
    }
    list->head = newNode;/*make sure head points new node*/

}

/*
 * function to insert last
 * this resemebles enqueueing movement
 * */
void insertLast(LinkedList *list, void *data)
{
    LinkedListNode *newNode = (LinkedListNode*)malloc(sizeof(LinkedListNode));
    newNode->next = NULL;
    newNode->prev = NULL;

    newNode->data = data;
   
    if (list->head == NULL)/*if list empty assign new node to head and tail*/
    {
        list->tail = newNode;
        list->head = newNode;
    }
    else
    {
        list->tail->next = newNode;/*assign new node after tail*/
        newNode->prev = list->tail;/*assign tail to previous of new node*/
    }
    list->tail = newNode;/*make sure tail points to new node*/

}

/*
 * function to delete from front
 * */
void* deleteFirst(LinkedList *list)
{
    LinkedListNode *currH, *currT;
    void* value;
    int length = getLength(list);
   
    currH = list->head;
    value = currH->data;

    if (length == 0 && currH == NULL)/*if list is empty value is null*/
    {
        value = NULL;
        printf("empty list\n");
    }

    if (currH->next == NULL)/*current tail will be NULL if current head next is NULL*/
    {
        currT = list->tail;
        currT = NULL;
    }
    else/*otherwise head previous will be assigned NULL */
    {
        currH->prev = NULL;
    }

    list->head = currH->next;/*make sure head points after current head*/
    free(currH);

    return value;
}

/*
 * function to do delete from back
 * */
void* deleteLast(LinkedList *list)
{
    LinkedListNode *currH, *currT;
    void* value;
    int length = getLength(list);
   
    currH = list->head;
    currT = list->tail;
    value = currH->data;

    if (length == 0 && currH == NULL)/*if list is empty value returned will be NULL*/
    {
        value = NULL;
        printf("empty list\n");
    }

    if (currH->next == NULL)/*current head will be NULL if head next is NULL*/
    {
        currH = NULL;
    }
    else/*otherwise current tail previous's next value will be NULL*/
    {
        currT->prev->next = NULL;
    }

    list->tail = currT->prev;/*make sure tail now points to current tail previous*/
    free(currT);

    return value;
}

/*
 * function to retrieve length of current list
 */
int getLength(LinkedList *list)
{
    int length = 0;
    LinkedListNode *curr = list->head;

    while (curr != NULL)
    {
        length = length + 1;
        curr = curr->next;
    }

    return length;
}

/*
 * function to retrieve element from list
 * */
void* getElement(LinkedList *list, int index)
{
    int i;
    int max = getLength(list);
    void* value;
    LinkedListNode *curr = list->head;

    if (index >= max)/*index exceeding list length gives null value*/
    {
        value = NULL;
    }
    else
    {
        i = 0;
        while (i <= index)/*loops until index is reached and retrieves value*/
        {
            i = i + 1;
            value = curr->data;
            curr = curr->next;
        }
    }

    return value;
}

/*
 * function to free linked list
 */
void freeLinkedList(LinkedList* list)
{
    LinkedListNode *node, *nextNode;
    
    node = list->head;
    while (node != NULL)
    {
        nextNode = node->next;
        free(node->data);/*free malloced data*/
        free(node);
        node = nextNode;
    }

    free(list);
}

/*
 * function to print list contents specifically for journal struct
 */
void printJournal(LinkedList* list)
{
    LinkedListNode *temp;
    Journal *journ;

    temp = list->head;

    while (temp != NULL)
    {
        journ = (Journal*)temp->data;/*obtain journal from list*/

        printf("%d-%d-%d: %s\n", journ->year, journ->month, journ->day, journ->text);
        temp = temp->next;
    }


}
