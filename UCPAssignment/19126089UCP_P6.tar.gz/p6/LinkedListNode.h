#ifndef LINKEDLISTNODE_H
#define LINKEDLISTNODE_H

typedef struct LinkedListNode
{
    void *data;
    struct LinkedListNode *next;
    struct LinkedListNode *prev;
}LinkedListNode;

typedef struct
{
    LinkedListNode *head;
    LinkedListNode *tail;
}LinkedList;

LinkedList* createLinkedList();
void insertFirst(LinkedList* list, void *data);
void insertLast(LinkedList *list, void *data);
void* deleteFirst(LinkedList *list);
void* deleteLast(LinkedList *list);
int getLength(LinkedList *list);
void* getElement(LinkedList *list, int index);
void freeLinkedList(LinkedList* list);
void printJournal(LinkedList* list);

#endif
