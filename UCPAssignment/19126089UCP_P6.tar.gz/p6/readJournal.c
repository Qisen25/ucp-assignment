#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "journal.h"

#define MAX_CHARS 100

void processFile(char *argv[]);
void printChoice(Journal *journ, int j);

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        printf("please enter a file and journal entry index\n");
    }
    else
    {
        processFile(argv);
    }

    return 0;
}

/*
 * function to read and print data stored in structed
 */
void processFile(char *argv[])
{
    FILE *file = fopen(argv[1], "r");
    char str[MAX_CHARS];
    int jIndex, rows, day, month, year, i;
    Journal *journ;

    jIndex = atoi(argv[2]);
    
    fscanf(file, "%d", &rows);/*get rows from first list*/
    journ = (Journal*)malloc(rows * sizeof(Journal));

    if (jIndex >= rows)
    {
        printf("index argument is greater than size of array\n");
    }
    else
    {
        i = 0;
        fgets(str, MAX_CHARS, file);/*skip first line containing rows*/
        while (fgets(str, MAX_CHARS, file) != NULL && i < rows)
        {
            if (sscanf(str, "%d/%d/%d", &day, &month, &year) == 3)/*if 3 fields found store date into struct*/
            {
                journ[i].day = day;        
                journ[i].month = month;        
                journ[i].year = year;
            }
            else
            {
                strcpy(journ[i].text, str);/*assign read in str to journ field 'text'*/
                i++;/*increment once message is found*/
            }
       
        }
        printChoice(journ, jIndex);
    }

    fclose(file);
    free(journ);
}

/*
 * function to print struct data specified by user
 */
void printChoice(Journal *journ, int j)
{
    printf("%d-%d-%d %s\n", journ[j].year, journ[j].month, journ[j].day, journ[j].text);   
}
