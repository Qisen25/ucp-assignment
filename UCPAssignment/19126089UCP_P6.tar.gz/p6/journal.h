#ifndef JOURNAL_H
#define JOURNAL_H

#define MAX_CHARS 100

typedef struct
{
    int day;
    int month;
    int year;
    char text[MAX_CHARS];
}Journal;

#endif
