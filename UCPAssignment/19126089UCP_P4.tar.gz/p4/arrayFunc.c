#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "arrayFunc.h"

int sum(int array[], int length)
{
    int i, sum;

    sum = 0;
    for (i = 0; i < length; i++)
    {
        sum = sum + array[i];
    }

    return sum;
}

int max(int array[], int length)
{
    int j, max, index;

    max = array[0];
    index = 0;
    for (j = 0; j < length; j++)
    {
        if ( array[j] > max)
        {
            max = array[j];
            index = j;
        }
    }

    return index;
}

void reverse(int array[], int length)
{
    int k, reverse, temp;

    k = 0;
    reverse = length - 1;
    while (k<reverse)
    {
        temp = array[k];
        array[k] = array[reverse];
        array[reverse] = temp;
        k++;
        reverse--;
    }

}

void stringToInt(char *stringArray[], int array[], int length)
{
    int i, temp;

    for (i = 0; i < length; i++)
    {
        temp = atoi(stringArray[i]);
        array[i] = temp;
    }
}

void outputArray(int array[], int length)
{
    int i;

    printf("{");
    for(i = 0; i < length; i++)
    {
        printf("%d",array[i]);
        if (i != length - 1)
        {
            printf(",");
        }
    }
    printf("}\n");
}

