
void storeIntString(char *array1[], char *arg[], int length);

void operations(char *op, int array[], int length);

void freeArgArray(char** sArray, int length);

void convertUpper(char* array);
