
int sum(int array[], int length);

int max(int array[], int length);

void reverse(int array[], int length);

void stringToInt(char *stringArray[], int array[], int length);

void outputArray(int array[], int length);
