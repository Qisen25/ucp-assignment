#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "arrayFunc.h"
#include "main.h"

#define NUM_ARGC 3
#define SKIP_ARGS 2

int main(int argc, char *argv[])
{
    int span;
    int *iArray;
    char **sArray; 
    if (argc < NUM_ARGC)
    {
        printf("Must have 2 arguments\n");
    }
    else
    {
        span = argc - 2;/*take 2 from argc to ignore first 2 args*/
    
        iArray = (int*)malloc(span * sizeof(int));
        sArray = (char**)malloc(span * sizeof(char*));

        storeIntString(sArray, argv, span);/*store integer aguments
                                            into separate string array*/
        
        stringToInt(sArray, iArray, span);/*convert separate array to int*/ 

        convertUpper(argv[1]);/*makes operation argument is upperCase*/

        operations(argv[1], iArray, span);

        freeArgArray(sArray, span);/* free pointer pointer array
                                    and contents in array*/
        free(iArray);
    }
           

    return 0;
}

void storeIntString(char *array[], char *arg[], int span)
{
    int j;
    for (j = 0; j < span; j++)
    {
        array[j] = (char*)malloc(sizeof(char*));

        strcpy(array[j], arg[SKIP_ARGS + j]);
    }
}

void operations(char *op, int array[], int span)
{
    int total, high;

    outputArray(array, span);/*output initial state of array*/
    if (strcmp(op, "SUM") == 0)
    {
        total = sum(array, span);
        printf("sum is %d\n", total);
    }
    else if (strcmp(op, "MAX") == 0)
    {
        high = max(array, span);
        printf("max is at index: %d\n", high);
    }
    else if (strcmp(op, "REVERSE") == 0)
    {
        reverse(array, span);
        outputArray(array, span);
    }
    else
    {
        printf("Invalid function argument\n");
    }
}

void freeArgArray(char **sArray, int span)
{
    int i;

    for (i = 0; i < span; i++)
    {
        free(sArray[i]);
    }
    free(sArray);
}

void convertUpper(char* array)
{
    int k, len;

    len = strlen(array);
    for (k = 0; k < len; k++)
    {
        if (array[k] > 96 && array[k] < 123)
        {
            array[k] = array[k] - 32;
        }
    }
}
